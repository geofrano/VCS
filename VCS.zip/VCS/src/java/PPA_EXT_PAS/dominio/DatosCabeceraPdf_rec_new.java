/*******************************************************************************

 ** MODIFICADO O CREADO:   CLS Julio Caamano
 ** PROYECTO:              [9553] Workflow Bodega Multicompania
 ** FECHA:                 12/09/2014
 ** LIDER CLS:             CLS Michael Coello
 ** LIDER SIS:             CLS Wendy Ramos
 * ******************************************************************************/

package  PPA_EXT_PAS.dominio;
public class DatosCabeceraPdf_rec_new {

    public String tipo=null;
    
    public String dato=null;
    
 
  public DatosCabeceraPdf_rec_new() {
        this.tipo=null;
        this.dato=null;
    };
    
       
    
}
